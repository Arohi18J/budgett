import streamlit as st

# Title to app
st.title("Finance & Budget calculator 🤑")
